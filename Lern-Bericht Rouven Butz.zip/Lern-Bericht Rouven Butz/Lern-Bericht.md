# Lern-Bericht
EA zu einem Teil des Auftrags LA_133_1005_SitzungsVerfolgung.

## Einleitung
In diesem Projekt sollten wir mehrere .html Seiten mit buttons verknüpfen, diese Seiten sollten verschiedene Eingaben verarbeiten können und diese später ausgeben. Da ich noch recht wenig Erfahrung mit JSF habe, wurde ein altes Projekt weiterentwickelt (Deshalb heisst das Projekt anders).

## Was habe ich gelernt?
Ich habe gelernt, wie ich zwischen den Seiten mit buttons wechseln kann.

## Beschreibung
Die buttons bestehen aus drei grundlegenden Blöcken. Man kann natürlich noch weitere hinzufügen, dass war für dieses Projekt aber noch nicht notwendig. Der erste Block ist die Syntax um die anderen beiden Blöcke, damit das Programm weiss, wo der button anfängt und wo dieser aufhört. Dieser wird mit <h:commandButton geöffnet und mit /> geschlossen. Der zweite Block ist die Schrift auf dem button. Diese wird mit value="Text" zugewiesen. Der dritte Block ist die Aktion. Diese wird mit action="" zugewiesen. In meinem Beispiel wird die gewünschte .html Seite aufgerufen. Ein essenzieller Teil ist, dass der commandButton von einem form eingeklammert wird. Dieses wird mit <h:form> geöffnet und mit </h:form> geschlossen. Ohne das form funktioniert der button nicht.

## Verifikation
Die Beschreibung, die beiden Bilder und der Code sollten verifizieren, dass ich diesen Auftrag ordnungsgemäss erledigt habe.

# Reflektion zum Arbeitsprozess
Ich habe das Prinzip schnell verstanden und konnte die Weiterleitung ohne Probleme implementieren. Ich habe aber anfangs etwas viel Zeit verschwendet, da ich das mit dem h:form nicht wusste und online keine passenden Tutorials fand.

**VBV**: Ich hätte meinen Sitznachbaren fragen sollen, hätte ich ihn nur gefragt, wo ich die richtigen Tutorials finde, hätte sich der Zeitaufwand drastisch verkürzt.
